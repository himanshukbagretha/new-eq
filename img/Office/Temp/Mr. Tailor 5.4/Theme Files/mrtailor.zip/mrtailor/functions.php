<?php

// Helpers.
require_once( get_template_directory() . '/functions/helpers/helpers.php');

// Customizer.
include_once( get_template_directory() . '/inc/customizer/config.php' );
include_once( get_template_directory() . '/inc/customizer/class/class-mrtailor-fonts.php' );
include_once( get_template_directory() . '/inc/customizer/class/class-mrtailor-opt.php' );
require_once( get_template_directory() . '/inc/customizer/class/class-mrtailor-icons.php');

// Custom Styles.
require_once( get_template_directory() . '/inc/custom-styles/custom-styles.php');

// Post Meta.
require_once( get_template_directory() . '/inc/templates/post-meta.php');

// Template Tags.
require_once( get_template_directory() . '/inc/templates/template-tags.php');

// Include Metaboxes.
require_once( get_template_directory() . '/inc/metaboxes/page.php');
require_once( get_template_directory() . '/inc/metaboxes/post.php');

// Theme Settings
include_once( get_template_directory() . '/functions/theme-setup.php' );
include_once( get_template_directory() . '/functions/theme-update.php' );

// Freemius
if ( ! function_exists( 'mrtailor_fs' ) ) {
    // Create a helper function for easy SDK access.
    function mrtailor_fs() {
        global $mrtailor_fs;

        if ( ! isset( $mrtailor_fs ) ) {

            require_once dirname(__FILE__) . '/dashboard/fs/start.php';

            $mrtailor_fs = fs_dynamic_init( array(
                'id'                  => '16117',
                'slug'                => 'mrtailor',
                'type'                => 'theme',
                'public_key'          => 'pk_632f8d1aa8f86eb31f09b2071f856',
                'is_premium'          => false,
                'has_addons'          => false,
                'has_paid_plans'      => false,
                'is_org_compliant'    => false,
                'menu'                => array(
                    'slug'           => 'getbowtied-dashboard',
                    'first-path'     => 'admin.php?page=getbowtied-dashboard',
                    'contact'        => false,
                    'support'        => false,
                ),
                'enable_anonymous' => false,
            ) );
        }

        return $mrtailor_fs;
    }

    mrtailor_fs();
    do_action( 'mrtailor_fs_loaded' );
}

// Admin Settings
if ( is_admin() ) {
	include_once( get_template_directory() . '/functions/admin-setup.php' );
	include_once( get_template_directory() . '/dashboard/setup.php' );
}

// Enqueue Styles.
include_once( get_template_directory() . '/functions/enqueue/admin-styles.php' );
include_once( get_template_directory() . '/functions/enqueue/styles.php' );

// Enqueue Scripts.
include_once( get_template_directory() . '/functions/enqueue/admin-scripts.php' );
include_once( get_template_directory() . '/functions/enqueue/scripts.php' );

// Widget Areas
include_once( get_template_directory() . '/functions/wp/header-functions.php' );
include_once( get_template_directory() . '/functions/wp/widget-areas.php' );

// WPBakery Page Builder.
if( MT_WPBAKERY_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/wb/wpbakery-setup.php' );
}

if( MT_WOOCOMMERCE_IS_ACTIVE ) {
	include_once( get_template_directory() . '/functions/wc/actions.php' );
	include_once( get_template_directory() . '/functions/wc/filters.php' );
	include_once( get_template_directory() . '/functions/wc/custom.php' );
}
