<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

include_once( get_template_directory() . '/dashboard/inc/pages/setup.php' );
include_once( get_template_directory() . '/dashboard/inc/pointers/pointers.php' );