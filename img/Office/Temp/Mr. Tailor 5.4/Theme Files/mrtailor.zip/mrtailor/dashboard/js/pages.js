jQuery(function($) {

	"use strict";

})